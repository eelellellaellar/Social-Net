package com.example.javafx;

import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Profile {
    private final SimpleStringProperty name;
    private final SimpleStringProperty status;
    private final SimpleStringProperty image;
    private final SimpleListProperty<String> friends;
    private final SimpleStringProperty quote;
    public Profile(String name) {
        this.name = new SimpleStringProperty(name);
        this.status = new SimpleStringProperty();
        this.image = new SimpleStringProperty();
        this.friends = new SimpleListProperty(FXCollections.observableArrayList());
        this.quote = new SimpleStringProperty();
    }
    public String getName() {
        return this.name.get();
    }
    public String getStatus() {
        return this.status.get();
    }
    public void setStatus(String status) {
        this.status.set(status);
    }
    public String getImageURL() {
        return this.image.get();
    }
    public void setImageURL(String imageURL) {
        this.image.set(imageURL);
    }
    public ObservableList<String> getFriends() {
        return this.friends.get();
    }
    public String getFavoriteQuote() {
        return this.quote.get();
    }
    public void setFavoriteQuote(String favoriteQuote) {
        this.quote.set(favoriteQuote);
    }
}
