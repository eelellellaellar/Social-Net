package com.example.javafx;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.Iterator;

public class Controller {

    public TextField nameField;
    public Label name;
    public Label statusLabel;
    public Label currentStatus;
    public TextField statusChangeLabel;
    public TextField pictureLabel;
    public TextField friendLabel;
    public TextField unfriendLabel;
    public TextField quoteLabel;
    public Label favoriteQuote;
    public ImageView pictureView;
    public ListView listView;
    ObservableList<Profile> profiles;
    ObservableList<String> friendList;

    @FXML
    private void initialize() {
        this.profiles = FXCollections.observableArrayList();
        this.friendList = FXCollections.observableArrayList();
        this.listView.setItems(this.friendList);
    }

    public void handleAdd(ActionEvent actionEvent) {
        if (!this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();

            if(findProfileByName(name) == null){

            Profile profile = new Profile(name);
            profile.setStatus(this.statusChangeLabel.getText());
            profile.setFavoriteQuote(this.quoteLabel.getText());
            this.profiles.add(profile);
            this.statusLabel.setText(name + " added");
            this.name.setText(" " + profile.getName());
            this.currentStatus.setText("Status: " + profile.getStatus());
            this.favoriteQuote.setText("Favorite Quote: " + profile.getFavoriteQuote());
            profile.getFriends().addAll(this.friendList);
            this.friendList.setAll(profile.getFriends());
            String imageUrl = this.pictureLabel.getText();

            if (!imageUrl.trim().isEmpty()) {
                profile.setImageURL(imageUrl);
                this.pictureView.setImage(new Image(imageUrl));
            }else{
                profile.setImageURL("unknown.png");
                this.pictureView.setImage(new Image("unknown.png"));
            }
        }else{
                this.statusLabel.setText("Profile Already Exsists");

            }

    }
}
    public void handleDelete (ActionEvent actionEvent) {
        if (!this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            if (profile != null) {
                this.profiles.remove(profile);
                this.statusLabel.setText(name + " deleted");
                this.clearProfile();
            } else {
                this.statusLabel.setText("Profile not found");
            }
        }
    }

    private void clearProfile() {
        this.nameField.clear();
        this.statusChangeLabel.clear();
        this.pictureLabel.clear();
        this.friendLabel.clear();
        this.unfriendLabel.clear();
        this.quoteLabel.clear();
        this.pictureView.setImage((Image)null);
        this.listView.getItems().clear();
        this.currentStatus.setText("");
        this.favoriteQuote.setText("");
        this.name.setText("");
    }

    private Profile findProfileByName(String name) {
        Iterator var2 = this.profiles.iterator();

        Profile profile;
        do {
            if (!var2.hasNext()) {
                return null;
            }

            profile = (Profile)var2.next();
        } while(!profile.getName().equalsIgnoreCase(name));

        return profile;
    }

    public void handleSearch (ActionEvent actionEvent){
        if (!this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            if (profile != null) {
                this.currentStatus.setText("" + profile.getStatus());
                this.favoriteQuote.setText("Favorite Quote: " + profile.getFavoriteQuote());
                this.name.setText(" " + profile.getName());
                this.friendList.setAll(profile.getFriends());
                this.statusLabel.setText(name + " searched");
                String imageUrl = profile.getImageURL();
                if (imageUrl != null) {
                    Image image = new Image(imageUrl);
                    this.pictureView.setImage(image);
                } else {
                    this.pictureView.setImage(null);
                }
            } else {
                this.statusLabel.setText("Profile not found");
                this.currentStatus.setText("");
                this.favoriteQuote.setText("");
                this.name.setText("");
                this.friendList.clear();
                this.pictureView.setImage(null);
            }
        }
    }

    public void handleStatus (ActionEvent actionEvent){
        if (!statusChangeLabel.getText().trim().isEmpty()&&!this.nameField.getText().trim().isEmpty()) {


            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            profile.setStatus(this.statusChangeLabel.getText());

            statusLabel.setText("status changed to " + statusChangeLabel.getText());
            currentStatus.setText(""+statusChangeLabel.getText());
        }
    }

    public void handlePicture (ActionEvent actionEvent){
        if (!pictureLabel.getText().trim().isEmpty()&&!this.nameField.getText().trim().isEmpty()) {

            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            String imageUrl = this.pictureLabel.getText();

            try {
                this.pictureView.setImage(new Image(imageUrl));
                profile.setImageURL(imageUrl);
                statusLabel.setText("picture changed to " + pictureLabel.getText());

            } catch (IllegalArgumentException e) {
                statusLabel.setText("Image '" +pictureLabel.getText() + "' not found");
            }
        }
    }


    public void handleAddFriend (ActionEvent actionEvent){
        if (!friendLabel.getText().trim().isEmpty()) {
            String name = this.friendLabel.getText();
            Profile profile = this.findProfileByName(name);

            if (profile != null) {
                friendList.add(friendLabel.getText());
                statusLabel.setText(friendLabel.getText() + " added as friend");
            }
            else{
                this.statusLabel.setText("Profile not found");
            }
        }
    }

    public void handleUnfriend (ActionEvent actionEvent){
        if (!unfriendLabel.getText().trim().isEmpty()) {

            String name = this.friendLabel.getText();
            Profile profile = this.findProfileByName(name);

            if (profile != null) {
                friendList.remove(unfriendLabel.getText());
                statusLabel.setText(unfriendLabel.getText() + " removed as friend");
            }
            else{
                this.statusLabel.setText("Profile not found");
            }
        }
    }

    public void handleQuote (ActionEvent actionEvent){
        if (!quoteLabel.getText().trim().isEmpty()) {

            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            profile.setFavoriteQuote(this.quoteLabel.getText());

            statusLabel.setText("Quote changed to " + quoteLabel.getText());
            favoriteQuote.setText(""+quoteLabel.getText());
        }
    }
}